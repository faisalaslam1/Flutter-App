import 'package:autogridapp/login.dart';
import 'package:flutter/material.dart';

void main() async {
  runApp(const AutoGrid());
}

class AutoGrid extends StatelessWidget {
  const AutoGrid({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AutoGrid Control',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const LoginScreen(), // ✅ Corrected here
    );
  }
}
