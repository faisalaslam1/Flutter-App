 import 'package:flutter/material.dart';
// ignore: unused_import
import 'package:shared_preferences/shared_preferences.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const homescreen(),
    );
  }
}
                                                                                                                                                                      
// ignore: camel_case_types
class homescreen extends StatefulWidget {
  const homescreen({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _homescreenState createState() => _homescreenState();
}

// ignore: camel_case_types
class _homescreenState extends State<homescreen>
    with SingleTickerProviderStateMixin {
  bool isDarkTheme = false;
  bool isNotificationEnabled = true;
  String selectedItem = "Select an Item";
  String selectedInfo = "Tap on a card to see details";
  late AnimationController _animationController;

  // 🆔 Add IDs for backend reference
  final Map<String, String> cardIDs = {
    'Temperature': 'temp_card',
    'Electricity': 'electricity_card',
    'Voltage': 'voltage_card',
    'System Health': 'system_health_card',
    'Save Energy': 'save_energy_card',
    'Fuel Level': 'fuel_level_card',
    'Connected Devices': 'connected_devices_card',
    'System Up': 'system_up_card',
    'System Down': 'system_down_card',
  };

  final Map<String, String> cardInfo = {
    "Temperature": "110°C",
    "Electricity": "100 Units",
    "Voltage": "110V",
    "System Health": "Excellent",
    "Save Energy": "Any switch is unreasonably ON",
    "Fuel Level": "4 Liters",
    "Connected Devices": "3 Connected Devices",
    "System Up": "All Usage Is Well",
    "System Down": "Some Defects",
  };
  
  get SharedPreferences => null;

  @override
  void initState() {
    super.initState();
    _loadTheme();
    _loadNotificationSetting();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 150),
      lowerBound: 0.95,
      upperBound: 1.0,
      vsync: this,
    )..forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      isDarkTheme = prefs.getBool('darkTheme') ?? false;
    });
  }

  Future<void> _loadNotificationSetting() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      isNotificationEnabled = prefs.getBool('notification') ?? true;
    });
  }

  void _toggleTheme(bool value) {
    setState(() {
      isDarkTheme = value;
    });
    _saveTheme(value);
  }

  void _toggleNotification(bool value) {
    setState(() {
      isNotificationEnabled = value;
    });
    _saveNotificationSetting(value);
  }

  Future<void> _saveTheme(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('darkTheme', value);
  }

  Future<void> _saveNotificationSetting(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notification', value);
  }

  void _updateHeader(String title) {
    setState(() {
      selectedItem = title;
      selectedInfo = cardInfo[title] ?? "No data available";
    });
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 1)),
    );
  }

  Widget _buildHeader() {
    return Container(
      key: const ValueKey('header_section'), // 🆔 Header section ID
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color.fromARGB(210, 100, 209, 164), Colors.lightBlue],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(30)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 30),
          Text(
            selectedItem,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            selectedInfo,
            style: const TextStyle(
              fontSize: 18,
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGridItem(IconData icon, String title, Color color) {
    return GestureDetector(
      key: ValueKey(cardIDs[title]), // 🆔 Add key for testing/backend access
      onTap: () {
        _animationController.forward(from: 0.95);
        _updateHeader(title);
        _showSnackBar('$title Clicked!');
      },
      child: ScaleTransition(
        scale: _animationController,
        child: Card(
          key: Key(cardIDs[title]!), // 🆔 Explicit key for the card
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          elevation: 8,
          shadowColor: color.withOpacity(0.5),
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            splashColor: color.withOpacity(0.2),
            onTap: () => _updateHeader(title),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: color.withOpacity(0.2),
                  child: Icon(icon, size: 30, color: color),
                ),
                const SizedBox(height: 10),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showThemeDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Select Theme'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.wb_sunny, color: Colors.orange),
                title: const Text('Light Theme'),
                onTap: () {
                  _toggleTheme(false);
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: const Icon(Icons.nights_stay, color: Colors.indigo),
                title: const Text('Dark Theme'),
                onTap: () {
                  _toggleTheme(true);
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showLanguageDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Select Language'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.language, color: Colors.blue),
                title: const Text('English'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: const Icon(Icons.language, color: Colors.green),
                title: const Text('Spanish'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: const Icon(Icons.language, color: Colors.red),
                title: const Text('French'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: const Icon(Icons.language, color: Colors.purple),
                title: const Text('German'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showNotificationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Notification Settings'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SwitchListTile(
                title: const Text('Enable Notifications'),
                value: isNotificationEnabled,
                onChanged: (value) {
                  _toggleNotification(value);
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showCheckForUpdateDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Check for Update'),
          content: const Text('Your app is up to date.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _showFindDeviceDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Find Device'),
          content: const Text('Searching...'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _showHistoryDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('History'),
          content: const Text('No history available.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _showPrivacyDialog() {
    TextEditingController oldPasswordController = TextEditingController();
    TextEditingController newPasswordController = TextEditingController();
    TextEditingController confirmPasswordController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Change Password'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: oldPasswordController,
                decoration: const InputDecoration(hintText: 'Old Password'),
                obscureText: true,
              ),
              TextField(
                controller: newPasswordController,
                decoration: const InputDecoration(hintText: 'New Password'),
                obscureText: true,
              ),
              TextField(
                controller: confirmPasswordController,
                decoration: const InputDecoration(hintText: 'Confirm Password'),
                obscureText: true,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                // Handle password change logic
                Navigator.pop(context);
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  void _showReportDialog() {
    TextEditingController reportController = TextEditingController();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Report'),
          content: TextField(
            controller: reportController,
            decoration: const InputDecoration(hintText: 'Enter your report'),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                // Handle report submission
                Navigator.pop(context);
              },
              child: const Text('Submit'),
            ),
          ],
        );
      },
    );
  }

  void _showGeneralSettingsDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          key: const ValueKey('settings_dialog'), // 🆔 Settings dialog ID
          title: const Text('General Settings'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: const Icon(Icons.language, color: Colors.blue),
                  title: const Text('Language'),
                  onTap: () {
                    Navigator.pop(context);
                    _showLanguageDialog();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.color_lens, color: Colors.purple),
                  title: const Text('Theme'),
                  onTap: () {
                    Navigator.pop(context);
                    _showThemeDialog();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.notifications, color: Colors.orange),
                  title: const Text('Notification'),
                  onTap: () {
                    Navigator.pop(context);
                    _showNotificationDialog();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.system_update, color: Colors.green),
                  title: const Text('Check for Update'),
                  onTap: () {
                    Navigator.pop(context);
                    _showCheckForUpdateDialog();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.history, color: Colors.indigo),
                  title: const Text('History'),
                  onTap: () {
                    Navigator.pop(context);
                    _showHistoryDialog();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.lock, color: Colors.red),
                  title: const Text('Privacy'),
                  onTap: () {
                    Navigator.pop(context);
                    _showPrivacyDialog();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.report, color: Colors.pink),
                  title: const Text('Report'),
                  onTap: () {
                    Navigator.pop(context);
                    _showReportDialog();
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Logout'),
          content: const Text('Are you sure you want to logout?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                // Handle logout
                Navigator.pop(context);
              },
              child: const Text('Confirm'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: isDarkTheme ? ThemeData.dark() : ThemeData.light(),
      home: Scaffold(
        appBar: AppBar(
          title: const Text(
            'AutoGrid Items',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
          ),
          centerTitle: true,
          backgroundColor: const Color.fromARGB(212, 100, 209, 164),
          actions: [
            PopupMenuButton<String>(
              onSelected: (String result) {
                switch (result) {
                  case 'find_device':
                    _showFindDeviceDialog();
                    break;
                  case 'general_settings':
                    _showGeneralSettingsDialog();
                    break;
                  case 'logout':
                    _showLogoutDialog();
                    break;
                }
              },
              itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                const PopupMenuItem<String>(
                  value: 'find_device',
                  child: Row(
                    children: [
                      Icon(Icons.search, color: Colors.blue),
                      SizedBox(width: 8),
                      Text('Find Device'),
                    ],
                  ),
                ),
                const PopupMenuItem<String>(
                  value: 'general_settings',
                  child: Row(
                    children: [
                      Icon(Icons.settings, color: Colors.green),
                      SizedBox(width: 8),
                      Text('General Settings'),
                    ],
                  ),
                ),
                const PopupMenuItem<String>(
                  value: 'logout',
                  child: Row(
                    children: [
                      Icon(Icons.logout, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Logout'),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
        body: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: GridView.count(
                crossAxisCount: 3,
                padding: const EdgeInsets.all(20),
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                children: [
                  _buildGridItem(Icons.thermostat, 'Temperature', Colors.red),
                  _buildGridItem(Icons.lightbulb, 'Electricity', Colors.orange),
                  _buildGridItem(Icons.health_and_safety, 'System Health', Colors.green),
                  _buildGridItem(Icons.bolt, 'Voltage', Colors.purple),
                  _buildGridItem(
                      Icons.energy_savings_leaf, 'Save Energy', Colors.blue),
                  _buildGridItem(Icons.ev_station, 'Fuel Level',
                      const Color.fromARGB(255, 140, 30, 0)),
                  _buildGridItem(
                      Icons.device_hub, 'Connected Devices', Colors.pink),
                  _buildGridItem(Icons.thumb_up, 'System Up', Colors.green),
                  _buildGridItem(Icons.thumb_down, 'System Down', Colors.red),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
